---
status: canonical
owner: engineering
last_verified: 2026-07-21
---

# Documentation Map and Authority

This index tells agents which documents are normative, which describe the current
implementation, and which are strategic or historical. A document is not
canonical merely because it is detailed.

## Status vocabulary

Every major design document should declare:

- `canonical` — normative behavior or ratified architecture;
- `current` — verified description of the implementation at a named date/commit;
- `proposed` — approved for discussion but not yet implemented;
- `historical` — retained for context only.

Documents marked `current` must include `last_verified`. When implementation
changes, update the document or mark it stale in the same change.

## Authority by question

| Question | Authority |
|---|---|
| What should the product do? | Canonical business-rule document |
| What architecture are we moving toward? | Ratified architecture/ADR |
| What is implemented now? | Current-status document plus current code |
| What tables and constraints exist? | `lib/db/src/schema/*`; `lib/db/SCHEMA.md` as a map |
| What does the API expose? | `lib/api-spec/openapi.yaml` |
| How should a routine change be made? | `docs/change-recipes.md` |
| What non-obvious regression lesson should I remember? | `.agents/memory/` after the above |

When the implementation differs from canonical business rules, do not rewrite the
business rule to match the bug. Record the gap in a current-status document.

## Canonical project documents

- [`../replit.md`](../replit.md) — stable agent operating contract and global
  invariants.
- [`change-recipes.md`](change-recipes.md) — routine implementation workflows.
- `../lib/db/SCHEMA.md` — table map; schema source is `lib/db/src/schema/`.

## Reconciliation

Read in this order:

1. [`reconciliation-status.md`](reconciliation-status.md) — verified current
   implementation, known drift, and active repair priorities.
2. [`workbench-business-rules.md`](workbench-business-rules.md) — canonical product
   semantics for row/card state and actions.
3. [`reconciliation-design.md`](reconciliation-design.md) — canonical money and
   relationship model. Historical migration commentary should be moved to an
   appendix/archive rather than treated as current state.
4. [`adr-source-link-ledger.md`](adr-source-link-ledger.md) — proposed
   evidence-to-evidence relationship ledger until its migration is complete.

The workbench rules are normative even when current code does not satisfy them.
The status document names those gaps.

## Other subsystems

- [`email-intelligence.md`](email-intelligence.md) — subsystem walkthrough. Add
  status metadata and a short current implementation section before relying on it
  for a structural change.
- [`crm-competitive-review.md`](crm-competitive-review.md) — product strategy and
  roadmap, not implementation authority. Move to `docs/product/` when paths are
  reorganized.

## Runbooks and migrations

Migration SQL and its paired runbook are operational authority for that migration
only. They do not override current architecture. Old migrations may reference
retired columns by necessity; agents must not treat those references as permission
to revive them.

## Documentation maintenance

- Keep `replit.md` stable and concise.
- Separate normative design from current implementation status and from history.
- Do not place contradictory generations of a design in one document without a
  clear historical appendix.
- Add a link here for every new canonical or current-status document.
- Archive superseded documents rather than leaving them discoverable as current.
