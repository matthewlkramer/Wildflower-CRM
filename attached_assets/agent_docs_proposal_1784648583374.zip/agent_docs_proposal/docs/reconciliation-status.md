---
status: current
owner: reconciliation
last_verified: 2026-07-21
verification_basis: static review of repository head 1f30bad0
---

# Reconciliation — Current Implementation Status

This document describes what the code currently does and where it diverges from
the canonical rules. It is not the business-rule authority. For intended behavior,
read `workbench-business-rules.md` and `reconciliation-design.md`.

Update this file whenever a listed gap is fixed or the authoritative relationship
model changes.

## Current relationship authorities

| Relationship | Current authority | Notes |
|---|---|---|
| Payment/evidence unit → CRM gift | `payment_applications` | Counted rows carry money; corroborating rows are audit evidence only. |
| Stripe payout → QuickBooks deposit | `settlement_links` | Proposed/confirmed lifecycle; status should derive from it. |
| Evidence → evidence | Existing frozen source-specific pointers | `source_links` is proposed in the ADR and is not yet the current authority. Do not add more pointers. |
| Opportunity lifecycle | Shared opportunity derivation | `loss_type` is the only user-set lifecycle override. |
| Gift QuickBooks tie | Live derivation from relationship data | The stored `quickbooks_tie_status` column and write-back applier are retired. |
| Loan vs revenue classification | `loan_or_grant` | Gift `type` and legacy `fundraising_category` are retired. |

## Current workbench surface

`/reconciliation/clusters` is the active unified cluster page. Legacy
reconciliation routes redirect to it. The page has real actions for a subset of
workflows, including linking/creating gifts, identifying donors, excluding and
re-including evidence, reverting some links, confirming/dismissing refund
proposals, flagging records, marking associated opportunities lost/dormant, and
searching for a QuickBooks settlement deposit.

Several displayed actions remain placeholders, including important cross-column,
group/split, repair, and bulk workflows. The cluster page should not be described
as having full parity with the retired workbenches until those flows are verified
end to end.

## Known architectural drift

### 1. Two row-state engines

Lens counts and page selection are derived from slim `f_*` SQL flags, while the UI
status is derived again during cluster hydration as `WorkbenchRowState`. This can
make lens membership, counts, displayed status, and actions disagree.

**Required correction:** derive all four from one canonical row-state projection.
Do not add another compatibility flag.

### 2. `audit_ready` is overstated

Current code treats settled accounting evidence as `qbComplete`, even though the
workflow for documenting required CRM information in QuickBooks is not complete.

**Required correction:** separate accounting-evidence linkage from QuickBooks
documentation completeness. `audit_ready` requires the latter.

### 3. Refund confirmation mutates CRM intent

Current refund propagation can reduce or archive the linked CRM gift. The canonical
workbench rule treats refund as a transaction fact: it changes live payment
coverage but does not by itself erase or resize donor intent.

**Required correction:** represent the reversal in payment/evidence coverage,
recompute row state, and leave gift/opportunity disposition to a separate human
decision. Do not extend the current gift-mutation behavior.

### 4. CRM-completeness predicates do not match the business rules

The coding-form path is currently satisfied too easily by an applied staging row,
while the donor-plus-allocation path requires a grant letter too broadly.

**Required correction:** implement the conditional document rules in
`workbench-business-rules.md` from one shared predicate used by lens routing,
hydration, and card display.

### 5. Transaction/card state is still partly legacy-derived

Frontend actions and tones continue to inspect legacy status/link fields and
fallback heuristics in addition to canonical state.

**Required correction:** include complete transaction and relationship state in
the canonical API shape; render and gate actions from that state only.

### 6. Accounting permissions are incomplete

Accounting-changing endpoints and frontend capabilities do not consistently
implement the finance authorization described in the business rules.

**Required correction:** enforce permission at the write boundary and expose
capabilities/blocking reasons to the UI.

### 7. CRM-only reconciliation is not a complete workflow

CRM-only rows can display a gift but cannot directly search for and attach payment
or accounting evidence. Some row layout and unlink behavior is relationship-
ambiguous.

**Required correction:** make the CRM card an equal starting point for searching,
linking, moving, and unlinking a specific relationship.

## Repair order

1. Disable or correct refund confirmation before extending refund UX.
2. Correct `audit_ready` and Completed-lens gating.
3. Consolidate row-state/lens derivation.
4. Correct CRM-completeness predicates.
5. Enforce finance permissions.
6. Make unlink and move actions relationship-specific.
7. Restore/retain access to any specialized workflow until cluster parity is
   demonstrated by end-to-end tests.

## Required invariant tests

- Lens count, returned membership, displayed state, and action capability agree for
  the same canonical row state.
- CRM-only complete gift remains information-complete while linkage is missing.
- A refunded transaction stops counting as live evidence without changing the CRM
  gift amount or archival state.
- `audit_ready` is impossible until required QuickBooks documentation is complete.
- Each CRM-completeness path implements conditional grant-letter rules.
- A non-finance user cannot create, confirm, remove, or replace an accounting link.
- Unlinking one relationship does not remove a sibling relationship in the cluster.
