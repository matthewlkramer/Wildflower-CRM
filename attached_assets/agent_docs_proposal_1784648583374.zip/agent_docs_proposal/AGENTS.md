# Agent entry point

Read and follow [`replit.md`](replit.md) before changing this repository.

`replit.md` is the single cross-agent operating contract. This file exists so
agents that discover `AGENTS.md` and Replit agents that discover `replit.md` use
the same instructions without maintaining two copies.
