# Wildflower Fundraising CRM — Agent Operating Guide

## Purpose

Wildflower CRM is the fundraising system of record for pipeline, commitments,
payments, donor communications, and financial reconciliation. The monorepo uses
TypeScript, React/Vite, Express, PostgreSQL/Drizzle, Clerk, OpenAPI, Orval, and
pnpm workspaces.

This file is the stable operating contract for coding agents. Keep it short. Put
subsystem design, implementation status, and troubleshooting details in the linked
documents rather than expanding this file.

## Start every task this way

1. Read this file.
2. Read [`docs/README.md`](docs/README.md) and the canonical document for the
   subsystem being changed.
3. Inspect `git status`, the current diff, the relevant schema, and the relevant
   API contract before proposing code.
4. State, briefly:
   - the concept being changed;
   - its current authoritative representation;
   - the shared mutation or derivation boundary;
   - the smallest relevant tests.
5. Only then edit code.

Do not load the entire `.agents/memory/` directory. Start with
[`.agents/memory/MEMORY.md`](.agents/memory/MEMORY.md), then read only the topic
files relevant to the task.

## Authority order

When sources disagree, use this order and surface the conflict instead of guessing:

1. The user's explicit instruction for the task.
2. Canonical business-rule documents identified in `docs/README.md`.
3. Ratified architecture decisions and current implementation-status documents.
4. Drizzle schema and database constraints for the current physical model.
5. `lib/api-spec/openapi.yaml` for the public API contract.
6. Shared domain services and derivation modules.
7. Route and UI implementations.
8. `.agents/memory/` implementation lessons.
9. Historical documents and deprecated code.

Schema and code describe what exists. Business-rule and architecture documents
describe what should exist. When those differ, do not silently treat the current
implementation as the intended design.

## Non-negotiable invariants

1. **Contract first.** Change `lib/api-spec/openapi.yaml`, regenerate, then
   implement. Never hand-edit generated files.
2. **Header plus allocations.** Opportunity/pledge and gift/payment headers hold
   identity and lifecycle facts. Scope, recipient, fiscal year, restriction,
   intended use, project, region, and sub-amount live on allocation rows.
3. **One authority per derived fact.** Lifecycle, reconciliation, totals, and
   completeness are derived once. Do not add stored status columns, copied SQL
   CASE expressions, route-local derivations, or frontend fallback heuristics for
   facts that already have an authority.
4. **Donor XOR.** Every opportunity and gift has exactly one organization,
   individual, or household donor. Validate merged PATCH state as well as create
   state.
5. **Loan and revenue remain separate.** `loan_or_grant` is the sole persisted
   classification. `gifts_and_payments.type` and the legacy
   `fundraising_category` model are retired and must not be revived.
6. **Canonical money relationships.** Use:
   - `payment_applications` for payment/evidence unit → CRM gift;
   - `settlement_links` for Stripe payout → QuickBooks deposit;
   - `source_links` only after its ADR is implemented for evidence ↔ evidence.
   Never add a sibling pointer or use the wrong relationship table.
7. **Refunds are transaction facts.** A refund removes or reduces live payment
   evidence. It does not, by itself, archive the CRM gift, rewrite donor intent,
   or prove the gift was never paid. Follow
   [`docs/workbench-business-rules.md`](docs/workbench-business-rules.md).
8. **Archive by default.** Hard deletion is allowed only in an explicitly
   documented and tested exception.
9. **Production is human-gated.** Agents do not write to production, publish,
   merge to `main`, or run production migrations unless explicitly instructed.
   Production data changes are reviewed, idempotent SQL applied by a human.
10. **Reduction is the architectural success criterion.** Prefer removing an
    authority, write path, fallback, or recomputation call site over adding a new
    representation beside it.

Stop and ask before implementing when a proposed fix:

- updates more than one copy of equivalent logic;
- adds a pointer, status, proposal field, cache, or fallback for an existing fact;
- reads or writes a deprecated, frozen, historical, or dual-write-only field;
- requires a new recomputation call site for a persisted derivative;
- changes money booking, reconciliation grain, donor identity, or lifecycle
  without an invariant test.

## Reconciliation-specific guard

Before any reconciliation change, read:

- [`docs/reconciliation-status.md`](docs/reconciliation-status.md) — what is
  currently implemented and known to be drifting;
- [`docs/workbench-business-rules.md`](docs/workbench-business-rules.md) —
  normative product semantics;
- [`docs/reconciliation-design.md`](docs/reconciliation-design.md) — target money
  and relationship model;
- [`docs/adr-source-link-ledger.md`](docs/adr-source-link-ledger.md) — proposed
  evidence-to-evidence ledger.

Required rules:

- The three semantic columns are donor/purpose, payment transaction, and
  accounting evidence. One physical record may serve more than one role.
- Link completeness and information completeness are independent.
- CRM completeness applies to every CRM card on the row, linked or not.
- `audit_ready` requires the required QuickBooks documentation, not merely the
  presence of accounting evidence.
- Completed-lens membership, counts, displayed status, and available actions must
  derive from the same canonical row state.
- Donorbox is donor/purpose evidence, not transaction evidence.
- Accounting-changing actions require the appropriate finance permission.

Do not extend a known implementation drift described in
`docs/reconciliation-status.md`; repair the canonical boundary first.

## Change workflow

### Routine code change

1. Find the recipe in [`docs/change-recipes.md`](docs/change-recipes.md).
2. Update the canonical contract/schema/deriver first.
3. Reuse the shared write service or transaction boundary.
4. Add or update the narrow invariant test.
5. Run scoped checks while iterating.
6. Run the required full checks once before finishing.
7. Update canonical documentation only when behavior or architecture changed.

### Schema or production-data change

- Additive and nullable/defaulted first.
- Add a uniquely numbered, idempotent migration and a runbook when ordering or
  data risk is non-trivial.
- Dev schema changes do not prove production readiness.
- Give human-run commands with `$PROD_DATABASE_URL` and a repo-root-relative path:

```bash
psql "$PROD_DATABASE_URL" -1 -v ON_ERROR_STOP=1 -f lib/db/migrations/<file>.sql
```

Do not place `BEGIN`/`COMMIT` inside a file applied with `psql -1`.

## Validation

Use the smallest checks that cover the change. Do not run several DB-backed test
commands concurrently; the dedicated test database intentionally serializes them.

| Change | Iteration checks | Before finishing |
|---|---|---|
| OpenAPI contract | regenerate alone, then `pnpm check:codegen` | relevant API/web checks |
| Shared library | `pnpm check:libs` + affected changed-scope tests | `pnpm check:full` |
| API server | `pnpm check:api` + `pnpm check:test-api-changed` | `pnpm check:test-api` + `pnpm check:full` |
| Frontend | `pnpm check:web` + `pnpm check:test-web-changed` | `pnpm check:test-web` + `pnpm check:full` |
| Browser flow | component/integration tests first | one focused e2e flow if behavior changed |

Run code generation by itself:

```bash
pnpm --filter @workspace/api-spec run codegen
```

The check is non-mutating; the regeneration command is not.

## Documentation and memory rules

- `replit.md` contains stable rules only; no benchmark counts, migration-phase
  diaries, or one-off incident notes.
- `docs/` contains canonical business rules, architecture, current status, and
  runbooks. Every major design doc should declare `status`, `owner`, and
  `last_verified`.
- `.agents/memory/` contains durable implementation lessons and routing indexes,
  not competing architecture. Follow `.agents/memory/README.md`.
- When a design changes, update or supersede the old document in the same change.
  Do not leave contradictory “current” statements in multiple files.
- Historical material belongs under an explicit `legacy/` or `archive/` path and
  must not be linked as current guidance.

## Project map

- `lib/db/` — schema, DB connection, migrations
- `lib/api-spec/` — canonical API contract
- `lib/api-client-react/` — generated React Query client
- `lib/api-zod/` — generated schemas plus shared invariant helpers
- `artifacts/api-server/` — Express API and domain services
- `artifacts/wildflower-crm/` — React application
- `docs/README.md` — documentation authority and subsystem map
- `.agents/memory/MEMORY.md` — selective implementation-memory index

## User working preferences

- Explain material tradeoffs and architectural consequences before a large change.
- Prefer a complete root-cause fix over a convincing local patch.
- In pickers, show blocked rows disabled with the blocking reason; do not hide
  them. Enforcement remains on the write endpoint with specific errors.
- Keep documentation and memory current, but do not create a new memory file for
  every task.
