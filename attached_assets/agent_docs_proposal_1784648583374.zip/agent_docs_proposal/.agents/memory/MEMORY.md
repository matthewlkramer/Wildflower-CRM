# Agent Memory Routing Index

Memory is supplemental implementation context, not canonical architecture. Read
only the sections relevant to the task. When memory conflicts with `replit.md`,
a canonical document, schema, or the current API contract, stop and surface the
conflict.

## Always start here

- [`../../replit.md`](../../replit.md) — agent operating contract and stable
  invariants.
- [`../../docs/README.md`](../../docs/README.md) — documentation authority,
  canonical subsystem documents, and status vocabulary.
- [Memory maintenance policy](README.md) — what belongs here and how to retire it.
- [Canonical architecture map](architecture-canon.md) — code and document entry
  points for non-trivial changes.

## Domain indexes

- [Money sync and reconciliation](money-sync-reconciliation.md) — QuickBooks,
  Stripe, Donorbox, payment applications, settlement links, source-link plan, and
  workbench implementation lessons. Read the linked canonical reconciliation docs
  before individual memory notes.
- [Email and calendar](email-calendar-sync.md) — Gmail/Calendar sync, tracking,
  intelligence, Flodesk, and deduplication.

## Core data-model invariants

- [Opportunity status is calculated](wildflower-opp-status-calculated.md)
- [Opportunity derivation is idempotent](opp-derivation-idempotency.md)
- [Donor XOR across split pickers](wildflower-donor-xor-pickers.md)
- [Gift always has an allocation](gift-allocation-seed-invariant.md)
- [Allocation restriction model](wildflower-allocation-restriction-ux.md)
- [Archive boundaries](archive-soft-delete-boundaries.md)
- [Loan and revenue tracks](loan-capital-fundraising-category.md)

## Delivery, database, and verification

- [Scoped validation checks](scoped-validation-checks.md)
- [Dedicated test database](dedicated-test-db.md)
- [Test-data hygiene](test-data-hygiene.md)
- [Publish diffs the dev database](publish-diffs-dev-database.md)
- [Cross-environment schema drift](cross-env-db-schema-drift.md)
- [Data migration ordering](data-migration-publish-ordering.md)
- [Drizzle SQL pitfalls](drizzle-pitfalls.md)
- [Orval and React Query patterns](orval-guide.md)
- [API-server HTTP integration tests](api-server-http-integration-tests.md)

## Frontend and interaction conventions

- [Unpickable rows remain visible with reasons](unpickable-rows-label-not-hide.md)
- [List-page chooser pattern](wildflower-list-chooser-pattern.md)
- [Stable list pagination and ordering](list-page-pagination.md)
- [Select-in-dialog scroll trap](select-in-dialog-scroll-trap.md)
- [Clerk e2e setup](playwright-e2e-clerk-setup.md)

## High-risk operational notes

Use these only when the symptom matches:

- [Replit database deletion recovery](replit-db-deletion-recovery.md)
- [Schema rename reconciliation](lifecycle-rename-reconciliation.md)
- [Post-merge push abort](post-merge-push-abort.md)
- [Missing workspace symlink](workspace-symlink-ts2307.md)
- [Production enum read cast](prod-executesql-enum-cast.md)

## Historical context

- [Legacy reconciliation pointer era](legacy-reconciliation/index.md) — regression
  context only. Never use as current implementation guidance.
- `legacy/` and any future `archive/` directory — historical only.

## Search rule

When the relevant index does not answer the question, search filenames and
frontmatter descriptions. Do not read all memory files. A useful memory note must
state a durable rule, why it matters, the current code/test anchor, and its
retirement condition when transitional.
