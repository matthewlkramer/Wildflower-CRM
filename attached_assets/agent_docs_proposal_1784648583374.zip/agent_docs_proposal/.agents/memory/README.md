---
name: Agent memory maintenance policy
status: canonical
owner: engineering
last_verified: 2026-07-21
---

# Agent memory maintenance policy

`.agents/memory/` is a cache of durable, non-obvious implementation lessons. It is
not the product specification, architecture record, migration history, task log,
or a substitute for reading current code.

## A memory file belongs here only when

- the rule is likely to matter again;
- the behavior is non-obvious from code and tests;
- forgetting it has caused or could cause a real regression;
- it can point to a current code boundary or invariant test;
- it does not duplicate a canonical document.

Do not create a memory file for a one-time task result, transient benchmark,
ordinary code path, UI screenshot iteration, or a problem already captured in a
test or runbook.

## Required frontmatter

```yaml
---
name: Human-readable topic
status: current | transitional | historical
owner: subsystem-name
last_verified: YYYY-MM-DD
description: One sentence describing the durable rule.
---
```

A `transitional` note must include the exact retirement condition. A `historical`
note must live under `legacy/` or `archive/` and must not be linked as current
implementation guidance.

## Required body

Keep current notes short—normally under 80 lines—and use this shape:

1. **Rule** — the durable instruction.
2. **Why** — the failure mode it prevents.
3. **Current anchors** — authoritative files/functions and the invariant test.
4. **How to apply** — only the non-obvious steps.
5. **Retirement condition** — required for transitional notes.

Avoid implementation chronology. Git history and migration runbooks hold history.

## Indexing

- `MEMORY.md` is a routing index, not a flat catalog.
- Link broad domain indexes and a small number of cross-cutting invariants.
- Individual gotchas should be reached through a domain index or search.
- Every current file must be reachable from `MEMORY.md` through at least one index.
- Orphan files are either linked, merged, or archived.

## Updating and pruning

When a task changes architecture or retires a field:

1. Update the canonical doc first.
2. Update the relevant domain index.
3. Rewrite or archive conflicting memory in the same change.
4. Search memory for the retired field/function/route and remove stale current
   guidance.
5. Do not preserve both old and new statements under `status: current`.

Quarterly—or after a major subsystem cutover—review current notes for:

- references to dropped schema columns or removed functions;
- routes and UI surfaces that no longer exist;
- benchmark counts or dates presented as permanent facts;
- notes that are now enforced by a clear invariant test and can be deleted;
- multiple files describing the same authority.
