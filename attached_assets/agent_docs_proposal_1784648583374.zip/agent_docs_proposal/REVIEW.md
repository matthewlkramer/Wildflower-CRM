# Agent Documentation and Memory Review

## Executive assessment

The repository contains strong architectural thinking, but the instruction system
has become too large and internally inconsistent for agents to use reliably.

- `replit.md` is 336 lines and mixes stable invariants, volatile implementation
  details, test benchmarks, feature catalog, and current migration status.
- `.agents/memory/` contains 208 Markdown files and roughly 80,000 words.
  `MEMORY.md` is a flat 84-line catalog rather than a routing index.
- Thirty-six memory files are unreachable from `MEMORY.md` through any link.
- Several “current” summaries contradict the files they link to or the latest code.
- `docs/reconciliation-design.md` contains multiple generations of the design,
  including contradictory statements about the accepted workbench.
- The strongest current product specification is
  `docs/workbench-business-rules.md`, but it is not clearly separated from current
  implementation status, and the code currently violates several of its rules.

The problem is not a lack of documentation. It is a lack of hierarchy, status,
and retirement discipline.

## Highest-priority contradictions

### `replit.md`

Rewrite rather than patch. Current stale statements include:

- Gift `type` is described as live even though it has been dropped.
- `fundraising_category` is described as still physical even though memory says the
  cutover/drop completed.
- `quickbooks_tie_status` is described as persisted and maintained by
  `applyGiftQbTieMany`, while current code derives it live and removed the write-back.
- Exact test counts and timing benchmarks are presented as permanent operating
  guidance.
- The feature catalog duplicates subsystem memory and will drift every time a
  cutover ships.

The proposed replacement keeps global invariants and workflow rules, then routes
the agent to current-status documents.

### `.agents/memory/MEMORY.md`

Replace the flat list with a routing index. The current index makes a one-line
incident note appear as authoritative as the architecture map. It also contains
stale summaries, for example saying gift type remains live while its linked topic
says it was dropped.

### `architecture-canon.md`

Rewrite after adopting `docs/README.md`. It currently says the canon is only
`replit.md` plus `SCHEMA.md` and still describes seven design principles. It should
explain the authority split among business rules, target architecture, current
status, schema, API contract, and memory.

### `money-sync-reconciliation.md`

Keep as a domain index, but rewrite its opening as a relationship-by-relationship
status table. It currently says the Stripe ledger read cutover is complete, then
later describes Stripe and Donorbox pointer columns as the link authority. It also
links stale gift-QB-tie and refund behavior as current guidance.

### `docs/reconciliation-design.md`

Split into:

1. a short canonical model;
2. current implementation status;
3. migration/history appendix.

The current 700-line file says the design is largely implemented, describes removed
pointer columns as current state, says the six-queue workbench is final in some
sections, and says the cluster workbench supersedes it in others. Agents cannot
reliably determine which statement controls.

### `docs/workbench-business-rules.md`

Keep as the normative product spec. Add status metadata and links to the current
status document. Do not weaken it to match current code. It correctly distinguishes
linkage from information, treats CRM-only missing evidence as ambiguous, requires
QuickBooks documentation for `audit_ready`, and keeps refund state on the
transaction.

### `docs/change-recipes.md`

Keep, but remove stale derived-field guidance:

- Delete `applyGiftQbTieMany` and persisted `quickbooks_tie_status` examples.
- Replace “recompute at every mutation” with “derive on read from the canonical
  relationship authority; if a cache/materialized projection is justified, name its
  invalidation contract explicitly.”
- Point the validation table back to `replit.md` rather than duplicating changing
  command details.
- Add a step to update current-status and memory documents when retiring a field or
  route.

## Memory restructuring

### Keep current and prominent

- Architecture routing
- Money/reconciliation domain index
- Email/calendar domain index
- Donor XOR
- Opportunity derivation
- Header/allocation model
- Archive boundaries
- Loan/revenue split
- Testing/database delivery indexes
- Drizzle and Orval consolidated gotchas

### Merge into broader indexes

- Individual Drizzle syntax incidents → `drizzle-pitfalls.md`
- Individual Orval incidents → `orval-guide.md`
- Test pollution incidents → `test-data-hygiene.md`
- Reconciliation queue/card implementation notes → a current workbench
  implementation index, with only still-live rules
- Publish/schema incidents → a deployment/database index

### Archive immediately or mark historical

At minimum:

- `gift-qb-tie-status.md`
- stale sections of `gift-booking-lifecycle-audit-close.md`
- `reconciliation-target-design.md` references to the retired two-report IA
- old queue-specific files referring to `reconciliation-workbench.tsx`
- `stripe-refund-propagation.md` as a description of current-but-noncanonical
  behavior, not a rule to extend
- pointer-era Stripe/QB/Donorbox notes that name dropped columns
- unreachable one-off incident files unless merged into a live index

### Orphan-file rule

The current archive contains 36 Markdown files with no incoming link. Every current
file should be reachable through one domain index. Unreachable files should be
merged, archived, or deleted—not silently retained.

## Agent files and skills

- `agent_assets_metadata.toml` is generated output metadata, not agent guidance. It
  should be excluded from architecture searches and periodically cleaned if Replit
  does not manage it automatically.
- The browser and frontend-design skills are generic and can remain opt-in.
- Add a small project-specific skill only if Replit does not consistently obey
  `replit.md`; otherwise avoid another duplicated instruction surface.
- Add root `AGENTS.md` as a pointer to `replit.md` so other coding agents discover the
  same contract.

## Recommended rollout

### Phase 1 — one focused documentation change

1. Replace `replit.md` and `MEMORY.md` with the proposed versions.
2. Add `AGENTS.md`, `docs/README.md`, `.agents/memory/README.md`, and
   `docs/reconciliation-status.md`.
3. Correct the stale `replit.md` facts immediately.
4. Add status metadata to `workbench-business-rules.md` and link the new status doc.
5. Update `architecture-canon.md` to match the new authority hierarchy.

No code or schema change is required.

### Phase 2 — reconciliation document cleanup

1. Extract historical phase notes from `reconciliation-design.md` into an archive.
2. Rewrite its opening current-state section from the actual relationship authority
   table.
3. Remove contradictory six-queue/cluster statements.
4. Rewrite `money-sync-reconciliation.md` and archive stale linked notes.
5. Update `change-recipes.md` derived-field recipe.

### Phase 3 — memory pruning

1. Generate a reachability report.
2. Merge duplicate Drizzle, Orval, test, and reconciliation notes.
3. Move historical files under `legacy/` or `archive/` with `status: historical`.
4. Add a lightweight lint that checks required frontmatter, broken links, and that
   every current memory file is reachable.

## Expected result

Agents should need to read:

1. one short operating guide;
2. one documentation map;
3. one subsystem status/design set;
4. a few selected memory notes.

They should not need to reconstruct architecture from 200 incident files or decide
which of several contradictory “current” statements is newest.
